<?php
$con=new mysqli('localhost','root','','databases',);
if(!$con){
    

    die(mysqli_error($con));
}
?>
